var radio_check1 = document.getElementsByName('one');
var radio_check2 = document.getElementsByName('two');
function validation(event) {
	var option3 = document.getElementById('selectOpt');
	var selectOpt = option3.options[option3.selectedIndex].value;
	if (selectOpt == '') {
		alert("Please select any one option");
		event.preventDefault();
		document.getElementById("third").style.display = "block";
		document.getElementById("second").style.display = "none";
		return false;
	} else {
		// All questons are answered 
	}
}
function next_step1() {
	if (radio_check1[0].checked == false && radio_check1[1].checked == false && radio_check1[2].checked == false && radio_check1[3].checked == false) {
		alert("Please select any one option");
		event.preventDefault();
		document.getElementById("first").style.display = "block";
		document.getElementById("second").style.display = "none";
		return false;
	} else {
		document.getElementById("first").style.display = "none";
		document.getElementById("second").style.display = "block";
		return true;
	}
}
function prev_step1() {
	document.getElementById("first").style.display = "block";
	document.getElementById("second").style.display = "none";
}
function next_step2() {
	if (radio_check2[0].checked == false && radio_check2[1].checked == false && radio_check2[2].checked == false && radio_check2[3].checked == false) {
		alert("Please select any one option");
		event.preventDefault();
		document.getElementById("second").style.display = "block";
		document.getElementById("third").style.display = "none";
		return false;
	} else {
		document.getElementById("second").style.display = "none";
		document.getElementById("third").style.display = "block";
		return true;
	}
}
function prev_step2() {
	document.getElementById("third").style.display = "none";
	document.getElementById("second").style.display = "block";
}
